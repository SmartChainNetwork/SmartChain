Sample configuration files for:
```
SystemD: smartchaind.service
Upstart: smartchaind.conf
OpenRC:  smartchaind.openrc
         smartchaind.openrcconf
CentOS:  smartchaind.init
macOS:    org.smartchain.smartchaind.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
